package com.microservices.employeeservice.service;

import org.springframework.stereotype.Service;

import com.microservices.employeeservice.dto.EmployeeDto;
import com.microservices.employeeservice.entity.Employee;
import com.microservices.employeeservice.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeRepository employeeRepository;
	
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		this.employeeRepository = employeeRepository;
	}



	@Override
	public EmployeeDto saveEmployee(EmployeeDto employeeDto) {
		Employee employee = new Employee(
				employeeDto.getEmployeeId(),
				employeeDto.getFirstName(),
				employeeDto.getLastName(),
				employeeDto.getEmail(),
				employeeDto.getDateOfJoining(),
				employeeDto.getCommunicationAddress()
				);
		
		// the below line will save the JPA entity into Database
		Employee savedEmployee = employeeRepository.save(employee);
		
		EmployeeDto savedEmployeeDto = new EmployeeDto(
				savedEmployee.getEmployeeId(),
				savedEmployee.getFirstName(),
				savedEmployee.getLastName(),
				savedEmployee.getEmail(),
				savedEmployee.getDateOfJoining(),
				savedEmployee.getCommunicationAddress()
				);
		return savedEmployeeDto;
//		Employee employee = new Employee();
//		employee.setEmployeeId(employeeDto.getEmployeeId());
//		employee.setFirstName(employeeDto.getFirstName());
//		employee.setLastName(employeeDto.getLastName());
//		employee.setEmail(employeeDto.getEmail());
//		employee.setDateOfJoining(employeeDto.getDateOfJoining());;
//		employee.setCommunicationAddress(employeeDto.getCommunicationAddress());
//		
////		EmployeeDto save = employeeRepository.save(employee);
	}



	@Override
	public EmployeeDto getEmployee(Long employeeId) {
		Employee employee = employeeRepository.findById(employeeId).get();
		
		EmployeeDto employeeDto = new EmployeeDto(
				employee.getEmployeeId(),
				employee.getFirstName(),
				employee.getLastName(),
				employee.getEmail(),
				employee.getDateOfJoining(),
				employee.getCommunicationAddress()
				);
		return employeeDto;
	}
	


}
