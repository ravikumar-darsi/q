package com.microservices.departmentservice.service;

import java.util.List;

import com.microservices.departmentservice.dto.DepartmentDto;

public interface DepartmentService {
	DepartmentDto saveDepartment(DepartmentDto departmentDto);
	
	DepartmentDto getDepartmentByCode(String code);
	
	List<DepartmentDto> getAllDepartments();

}
