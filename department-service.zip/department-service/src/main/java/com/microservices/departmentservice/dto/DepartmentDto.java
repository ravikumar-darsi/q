package com.microservices.departmentservice.dto;

public class DepartmentDto {
	private Long deparId;
	private String departmentName;
	private String departmentDescription;
	private String departmentCode;
	public DepartmentDto(Long deparId, String departmentName, String departmentDescription, String departmentCode) {
		super();
		this.deparId = deparId;
		this.departmentName = departmentName;
		this.departmentDescription = departmentDescription;
		this.departmentCode = departmentCode;
	}
	public DepartmentDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getDeparId() {
		return deparId;
	}
	public void setDeparId(Long deparId) {
		this.deparId = deparId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getDepartmentDescription() {
		return departmentDescription;
	}
	public void setDepartmentDescription(String departmentDescription) {
		this.departmentDescription = departmentDescription;
	}
	public String getDepartmentCode() {
		return departmentCode;
	}
	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

}
