package com.microservices.departmentservice.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.microservices.departmentservice.dto.DepartmentDto;
import com.microservices.departmentservice.entity.Department;
import com.microservices.departmentservice.repository.DepartmentRepo;

@Service
public class DepartmentServiceImpl  implements DepartmentService{
	private DepartmentRepo departmentRepo;
	

	public DepartmentServiceImpl(DepartmentRepo departmentRepo) {
		this.departmentRepo = departmentRepo;
	}


	@Override
	public DepartmentDto saveDepartment(DepartmentDto departmentDto){
		//Covert DepartmentDto to Department JPA Entity
		Department department = new Department(
				departmentDto.getDeparId(),
				departmentDto.getDepartmentName(),
				departmentDto.getDepartmentDescription(),
				departmentDto.getDepartmentCode()
			);
		
		Department savedDepartment = departmentRepo.save(department);
		
		DepartmentDto savedDepartmentDto = new DepartmentDto(
				savedDepartment.getDeparId(),
				savedDepartment.getDepartmentName(),
				savedDepartment.getDepartmentDescription(),
				savedDepartment.getDepartmentCode()
			);
		return savedDepartmentDto;
	}


	@Override
	public DepartmentDto getDepartmentByCode(String departmentCode) {
		Department department = departmentRepo.findByDepartmentCode(departmentCode);
		DepartmentDto departmentDto = new DepartmentDto(
				department.getDeparId(),
				department.getDepartmentName(),
				department.getDepartmentDescription(),
				department.getDepartmentCode()
				
				);
		return departmentDto;
	}


	@Override
	public List<DepartmentDto> getAllDepartments() {
		List<Department> departments = departmentRepo.findAll();
		
		List<DepartmentDto> departmentDto = departments.stream()
				.map(department -> new DepartmentDto(
						department.getDeparId(),
						department.getDepartmentName(),
						department.getDepartmentDescription(),
						department.getDepartmentCode()
						)).collect(Collectors.toList());
		return departmentDto;
	}

}
